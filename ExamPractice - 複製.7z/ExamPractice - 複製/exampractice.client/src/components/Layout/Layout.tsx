import React from 'react';

type BannerProps = { children: React.ReactNode };

function Layout(props: BannerProps) {
    return (
        <div className='container-fluid'>
            <div className='row'>
                <div className='col-md-2 d-none d-md-block bg-light sidebar'>nav</div>
            </div>
            <main role='' className='col-md-9 ml-sm-auto col-lg-10 px-4'>
                {props.children}
            </main>
        </div>
    );
}

export { Layout };
