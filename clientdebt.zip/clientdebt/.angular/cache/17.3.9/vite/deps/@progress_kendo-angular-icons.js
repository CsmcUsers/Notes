import {
  ICON_SETTINGS,
  IconComponent,
  IconModule,
  IconSettingsService,
  IconWrapperComponent,
  IconsModule,
  IconsService,
  SVGIconComponent,
  SVGIconModule
} from "./chunk-4YSKD6C2.js";
import "./chunk-7QA7BPLB.js";
import "./chunk-XVQKNWAT.js";
import "./chunk-DAS2HZ5P.js";
import "./chunk-HXGTP3WH.js";
import "./chunk-YJ3WXPBJ.js";
import "./chunk-WD76XF4G.js";
import "./chunk-GLLL6ZVE.js";
export {
  ICON_SETTINGS,
  IconComponent,
  IconModule,
  IconSettingsService,
  IconWrapperComponent,
  IconsModule,
  IconsService,
  SVGIconComponent,
  SVGIconModule
};
//# sourceMappingURL=@progress_kendo-angular-icons.js.map
