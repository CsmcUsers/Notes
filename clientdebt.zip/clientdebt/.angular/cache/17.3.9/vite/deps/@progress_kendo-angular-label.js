import {
  CustomMessagesComponent,
  FloatingLabelComponent,
  FloatingLabelModule,
  LabelComponent,
  LabelDirective,
  LabelModule,
  LocalizedMessagesDirective,
  SharedDirectivesModule
} from "./chunk-5WV756GH.js";
import "./chunk-F6ZKO5N5.js";
import "./chunk-7QA7BPLB.js";
import "./chunk-56THBIXE.js";
import "./chunk-XVQKNWAT.js";
import "./chunk-YJ3WXPBJ.js";
import "./chunk-WD76XF4G.js";
import "./chunk-GLLL6ZVE.js";
export {
  CustomMessagesComponent,
  FloatingLabelComponent,
  FloatingLabelModule,
  LabelComponent,
  LabelDirective,
  LabelModule,
  LocalizedMessagesDirective,
  SharedDirectivesModule
};
//# sourceMappingURL=@progress_kendo-angular-label.js.map
