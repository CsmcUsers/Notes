import { inject, Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, ɵHttpInterceptingHandler } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { ErrorHandlerService } from '../services/error-handler.service';
import { HttpInterceptorFn } from '@angular/common/http';
/**
 * 如果使用 implements HttpInterceptor 會出現錯誤不知道為什麼
 */
// @Injectable()
// export class ErrorInterceptor implements HttpInterceptor {
//     constructor() {}

//     intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
//         console.log('error interceptor...');
//         return next.handle(request);
//     }
// }

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
    console.log('error interceptor...');
    const errfn = inject(ErrorHandlerService).handleError;

    return next(req).pipe();
};
