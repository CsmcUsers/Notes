import { Component, EventEmitter, Input, Output } from '@angular/core';
import { menuIcon, paletteIcon, SVGIcon } from '@progress/kendo-svg-icons';
import { AvatarModule } from '@progress/kendo-angular-layout';
import { DropDownListModule, SharedDirectivesModule } from '@progress/kendo-angular-dropdowns';
import { NgClass, NgIf } from '@angular/common';
import { SVGIconModule } from '@progress/kendo-angular-icons';

@Component({
    selector: 'app-header-component',
    templateUrl: './header.commponent.html',
    standalone: true,
    imports: [SVGIconModule, NgIf, DropDownListModule, NgClass, SharedDirectivesModule, AvatarModule],
})
export class HeaderComponent {
    @Output() public toggle = new EventEmitter();
    @Input() public selectedPage?: string;

    public menuIcon: SVGIcon = menuIcon;
    public paletteIcon: SVGIcon = paletteIcon;
    public popupSettings = { width: '150' };
    public themes: { href: string; text: string }[] = [
        {
            href: 'assets/kendo-theme-default/dist/all.css',
            text: 'Default',
        },
        {
            href: 'assets/kendo-theme-bootstrap/dist/all.css',
            text: 'Bootstrap',
        },
        {
            href: 'assets/kendo-theme-material/dist/all.css',
            text: 'Material',
        },
    ];
    public selectedTheme = this.themes[1];

    public changeTheme(theme: { href: string; text: string }) {
        this.selectedTheme = theme;
        const themeEl: any = document.getElementById('theme');
        themeEl.href = theme.href;
    }

    public onButtonClick(): void {
        this.toggle.emit();
    }
}
