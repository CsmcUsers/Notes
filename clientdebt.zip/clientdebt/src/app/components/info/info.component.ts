import { Component } from '@angular/core';

@Component({
    selector: 'app-info-component',
    templateUrl: './info.component.html',
    standalone: true,
})
export class InfoComponent {}
