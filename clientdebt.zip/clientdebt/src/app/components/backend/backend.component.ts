import { Component, OnInit, signal, WritableSignal, effect, input } from '@angular/core';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { ButtonGroupModule, ButtonModule } from '@progress/kendo-angular-buttons';
import { DataBindingDirective } from '@progress/kendo-angular-grid';
import { employees } from './employees';
import { State } from '@progress/kendo-data-query';
import { GridModule } from '@progress/kendo-angular-grid';
import { IndicatorsModule } from '@progress/kendo-angular-indicators';
import { tap, switchMap, single } from 'rxjs/operators';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClientServiceService, ApiServiceService } from '../../services';
import { ErrorHandlerService } from '../../services/error-handler.service';

@Component({
    selector: 'app-backend',
    templateUrl: './backend.component.html',
    standalone: true,
    imports: [LayoutModule, ButtonGroupModule, ButtonModule, GridModule, IndicatorsModule],
    styles: `
        .loading-container {
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }
    `,
})
export class BackendComponent implements OnInit {
    emp = <any>[];
    loading: boolean = false;
    public state = {
        skip: 0,
        take: 7,
    };

    readonly aa: WritableSignal<number> = signal(0);

    bb: number = 0;

    // optional
    firstName = input<string>(); // InputSignal<string|undefined>
    age = input(0); // InputSignal<number>
    // required
    lastName = input.required<string>(); // InputSignal<string>

    constructor(
        private apiService: HttpClientServiceService,
        private apiLocal: ApiServiceService,
        private errorhandler: ErrorHandlerService
    ) {
        effect(() => {
            console.log('aa', this.aa());
        });
    }

    ngOnInit() {
        this.apiService.getPosts().subscribe((data) => {
            console.log(data);
            this.emp = data;
        });
    }

    onAddOne() {
        this.aa.update((p) => p + 3);
    }

    onAddLocal() {
        this.bb = this.bb + 1;
    }

    onFetchWeatherForecast() {
        this.apiLocal.getPost('api/Test/HI').subscribe((data) => {
            console.log(data);
        });
    }
}
