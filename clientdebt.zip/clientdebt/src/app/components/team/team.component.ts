import { Component, OnInit, ViewChild } from '@angular/core';
import {
    DataBindingDirective,
    GridModule,
    ExcelModule,
    PDFModule,
    BodyModule,
    SharedModule,
} from '@progress/kendo-angular-grid';
import { process } from '@progress/kendo-data-query';
import { SVGIcon, fileExcelIcon, filePdfIcon } from '@progress/kendo-svg-icons';
import { Employee } from '../../models/employee.model';
import { employees } from '../../resources/employees';
import { images } from '../../resources/images';
import { SparklineModule, ChartModule } from '@progress/kendo-angular-charts';
import { RatingComponent } from './rating.component';
import { NgStyle, NgIf, NgClass, CurrencyPipe } from '@angular/common';
import { TextBoxModule } from '@progress/kendo-angular-inputs';
import { ButtonGroupModule, ButtonModule } from '@progress/kendo-angular-buttons';

@Component({
    selector: 'app-team-component',
    templateUrl: './team.component.html',
    standalone: true,
    imports: [
        ButtonGroupModule,
        ButtonModule,
        GridModule,
        TextBoxModule,
        ExcelModule,
        PDFModule,
        BodyModule,
        SharedModule,
        NgStyle,
        NgIf,
        RatingComponent,
        SparklineModule,
        ChartModule,
        NgClass,
        CurrencyPipe,
    ],
})
export class TeamComponent implements OnInit {
    @ViewChild(DataBindingDirective) dataBinding?: DataBindingDirective;

    public gridData: Employee[] = employees;
    public gridView: any[] = [];
    public excelIcon: SVGIcon = fileExcelIcon;
    public pdfIcon: SVGIcon = filePdfIcon;

    public mySelection: string[] = [];

    public ngOnInit(): void {
        this.gridView = this.gridData.slice(25, 50);

        console.log('jiooij');
    }

    // Update Grid collection during changing My Team/All Team
    public onTeamChange(pageSize: number): void {
        pageSize === 25
            ? (this.gridView = this.gridData.slice(pageSize, pageSize * 2))
            : (this.gridView = this.gridData.slice(0, pageSize));
    }

    public onFilter(inputValue: string): void {
        this.gridView = process(this.gridData, {
            filter: {
                logic: 'or',
                filters: [
                    {
                        field: this.getField,
                        operator: 'contains',
                        value: inputValue,
                    },
                ],
            },
        }).data;

        this.dataBinding ? (this.dataBinding.skip = 0) : null;
    }

    public getField = (args: Employee) => {
        return `${args.fullName}_${args.jobTitle}_${args.budget}_${args.phone}_${args.address}`;
    };

    public photoURL(dataItem: any): string {
        const code: string = dataItem.imgId + dataItem.gender;
        const image: any = images;

        return image[code];
    }
    public flagURL(dataItem: any): string {
        const code: string = dataItem.country;
        const image: any = images;

        return image[code];
    }
}
