import { Component, signal, WritableSignal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from '@progress/kendo-angular-buttons';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { ExcelModule, GridModule } from '@progress/kendo-angular-grid';
import { FormFieldModule, TextBoxModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { fileExcelIcon, plusIcon } from '@progress/kendo-svg-icons';

import { Record } from './record';

@Component({
    selector: 'app-record',
    standalone: true,
    imports: [
        ButtonModule,
        DialogModule,
        ExcelModule,
        FormFieldModule,
        GridModule,
        LabelModule,
        ReactiveFormsModule,
        TextBoxModule,
    ],
    templateUrl: './record.component.html',
})
export class RecordComponent {
    protected records: Record[] = [
        {
            uuid: 'uuid1',
            branch: '2350',
            account: '110110110110',
            borrower: '王小明',
            lodger: '王小明',
            lodgedReason: '假扣押',
            caseNumber: '91年存',
            lodgedLocation: '高地院提所',
            lodgedItem: '高債91-1',
            lodgedAmount: '1000000',
            lodgedDate: '2019-02-01',
        },
        {
            uuid: 'uuid2',
            branch: '2350',
            account: '120120120120',
            borrower: '王中明',
            lodger: '王中明',
            lodgedReason: '假扣押',
            caseNumber: '92年存',
            lodgedLocation: '高地院提所',
            lodgedItem: '高債91-1',
            lodgedAmount: '1500000',
            lodgedDate: '2020-02-01',
        },
        {
            uuid: 'uuid1',
            branch: '2350',
            account: '130130130130',
            borrower: '王大明',
            lodger: '王大明',
            lodgedReason: '假扣押',
            caseNumber: '93年存',
            lodgedLocation: '高地院提所',
            lodgedItem: '高債91-1',
            lodgedAmount: '2000000',
            lodgedDate: '2021-02-01',
        },
    ];

    protected recordForm = new FormGroup({
        branch: new FormControl(''),
        account: new FormControl(''),
        borrower: new FormControl(''),
        lodger: new FormControl(''),
        lodgedReason: new FormControl(''),
        caseNumber: new FormControl(''),
        lodgedLocation: new FormControl(''),
        lodgedItem: new FormControl(''),
        lodgedAmount: new FormControl(''),
        lodgedDate: new FormControl(''),
    });

    protected recordFormControls = [
        {
            text: '帳號',
            formControlName: 'account',
        },
        {
            text: '借戶名稱',
            formControlName: 'borrower',
        },
        {
            text: '提存對象',
            formControlName: 'lodger',
        },
        {
            text: '提存原因',
            formControlName: 'lodgedReason',
        },
        {
            text: '案號',
            formControlName: 'caseNumber',
        },
        {
            text: '提存處所',
            formControlName: 'lodgedLocation',
        },
        {
            text: '提存物',
            formControlName: 'lodgedItem',
        },
        {
            text: '總金額',
            formControlName: 'lodgedAmount',
        },
        {
            text: '提存日期',
            formControlName: 'lodgedDate',
        },
    ];

    protected readonly newRecordFormOpened: WritableSignal<boolean> = signal(false);

    protected readonly closeNewRecordForm = (): void => {
        this.newRecordFormOpened.set(false);
    };

    protected readonly newRecordFromForm = (): void => {
        this.closeNewRecordForm();

        this.records.push(<Record>{
            uuid: 'uuid1',
            branch: '2350',
            account: this.recordForm.value.account,
            borrower: this.recordForm.value.borrower,
            lodger: this.recordForm.value.lodger,
            lodgedReason: this.recordForm.value.lodgedReason,
            caseNumber: this.recordForm.value.caseNumber,
            lodgedLocation: this.recordForm.value.lodgedLocation,
            lodgedItem: this.recordForm.value.lodgedItem,
            lodgedAmount: this.recordForm.value.lodgedAmount,
            lodgedDate: this.recordForm.value.lodgedDate,
        });

        console.log(this.records);

        this.recordForm.reset();
    };

    protected readonly fileExcelIcon = fileExcelIcon;
    protected readonly plusIcon = plusIcon;

    protected readonly Math = Math;
    protected readonly window = window;
}
