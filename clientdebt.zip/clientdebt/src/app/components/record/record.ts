export interface Record {
    uuid: string;

    // 分行別
    branch: string;

    // 帳號
    account: string;

    // 借戶名稱
    borrower: string;

    // 提存對象
    lodger: string;

    // 提存原因
    lodgedReason: string;

    // 案號
    caseNumber: string;

    // 提存處所
    lodgedLocation: string;

    // 提存物
    lodgedItem: string;

    // 總金額
    lodgedAmount: string;

    // 提存日期
    lodgedDate: string;
}
