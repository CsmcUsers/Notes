import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationStart, Router, RouterOutlet } from '@angular/router';
import { DrawerComponent, DrawerMode, DrawerSelectEvent, DrawerModule } from '@progress/kendo-angular-layout';
import {
    gridIcon,
    chartLineMarkersIcon,
    calendarIcon,
    userIcon,
    infoCircleIcon,
    html5Icon,
} from '@progress/kendo-svg-icons';
import { HeaderComponent } from './header/header.component';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    standalone: true,
    imports: [HeaderComponent, DrawerModule, RouterOutlet],
})
export class AppComponent implements OnInit, OnDestroy {
    public selected = 'Team';
    public items: Array<any> = [];
    public mode: DrawerMode = 'push';
    public mini = true;

    constructor(private router: Router) {}

    ngOnInit() {
        // Update Drawer selected state when change router path
        this.router.events.subscribe((route: any) => {
            if (route instanceof NavigationStart) {
                this.items = this.drawerItems().map((item) => {
                    if (item.path && item.path === route.url) {
                        item.selected = true;
                        return item;
                    } else {
                        item.selected = false;
                        return item;
                    }
                });
            }
        });

        this.setDrawerConfig();

        window.addEventListener('resize', () => {
            this.setDrawerConfig();
        });
    }

    ngOnDestroy() {
        window.removeEventListener('resize', () => {});
    }

    public setDrawerConfig() {
        const pageWidth = window.innerWidth;
        if (pageWidth <= 840) {
            this.mode = 'overlay';
            this.mini = false;
        } else {
            this.mode = 'push';
            this.mini = true;
        }
    }

    public drawerItems() {
        return [
            {
                text: 'Record',
                svgIcon: html5Icon,
                path: '/record',
                selected: false,
            },
            {
                text: '後台',
                svgIcon: html5Icon,
                path: '/backend',
                selected: false,
            },
            {
                text: 'Team',
                svgIcon: gridIcon,
                path: '/',
                selected: true,
            },
            {
                text: 'Dashboard',
                svgIcon: chartLineMarkersIcon,
                path: '/dashboard',
                selected: false,
            },
            {
                text: 'Planning',
                svgIcon: calendarIcon,
                path: '/planning',
                selected: false,
            },
            {
                text: 'Profile',
                svgIcon: userIcon,
                path: '/profile',
                selected: false,
            },
            { separator: true },
            {
                text: 'Info',
                svgIcon: infoCircleIcon,
                path: '/info',
                selected: false,
            },
        ];
    }

    public toggleDrawer(drawer: DrawerComponent): void {
        drawer.toggle();
    }

    public onSelect(ev: DrawerSelectEvent): void {
        this.router.navigate([ev.item.path]);
        this.selected = ev.item.text;
    }
}
