export class Team {
    public teamID?: number;
    public teamName?: string;
    public teamColor?: string;
}
