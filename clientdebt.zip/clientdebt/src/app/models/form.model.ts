export class FormModel {
    public avatar?: any[];
    public firstName?: string;
    public lastName?: string;
    public email?: string;
    public phoneNumber?: string;
    public directory?: boolean;
    public country?: string;
    public biography?: string;
    public team?: string;
}
