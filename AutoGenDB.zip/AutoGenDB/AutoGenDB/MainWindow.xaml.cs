﻿using AutoGenDB.model;
using AutoGenDB.serv;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoGenDB
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        private dbServ _dbServ             = new dbServ();
        private CSharpModelServ _modelServ = new CSharpModelServ(); 

        private string _connstr = "";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Load_Click(object sender, RoutedEventArgs e)
        {
            string dest   = txtDataSource.Text;
            string usr    = txtUserID.Text;
            string passwd = txtPassword.Text;

            if (string.IsNullOrEmpty(dest) || string.IsNullOrEmpty(usr) || string.IsNullOrEmpty(passwd))
            {
                return;
            }

            _connstr = new SqlConnectionStringBuilder
                                {
                                    DataSource = dest,
                                    UserID = usr,
                                    Password = passwd
                                }.ToString();

            List<DB> dBs = _dbServ.GetDataBase(_connstr);

            dlInitialCatalog.ItemsSource = dBs;

            dlcbTables.ItemsSource = null;
        }

        /// <summary>
        /// 選擇資料庫
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dlInitialCatalog_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            string dest = txtDataSource.Text;
            string usr = txtUserID.Text;
            string passwd = txtPassword.Text;

            _connstr = new SqlConnectionStringBuilder
            {
                DataSource = dest,
                UserID = usr,
                Password = passwd,
                InitialCatalog = dlInitialCatalog.SelectedValue.ToString()
            }.ToString();


            List<Tables> tables = _dbServ.GetDataTables(_connstr, TableLike.Text.Trim());

            dlcbTables.ItemsSource = tables;
        }

        /// <summary>
        /// 選擇table
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dlcbTables_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            string fulltableName = ((Tables)dlcbTables.SelectedValue)?.TABLE_NAME;

            if (string.IsNullOrEmpty(fulltableName))
            {
                return;
            }

            string schema = fulltableName.Split('.')[0];
            string tableName = fulltableName.Split('.')[1];

            List<DataType> dataTypes = _dbServ.GetDataTypes(_connstr, schema, tableName);

            switch (dlOutPutType.Text)
            {

                case "C# Model":

                    Sql.Text = _modelServ.GetModelCode(schema, tableName, dataTypes, new List<string> { });
                    break;
                case "JS Column":

                    Sql.Text = _modelServ.GetJSColumnCode(schema, tableName, dataTypes);
                    break;
            }

        }

        /// <summary>
        /// 模糊找尋table
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TableLike_TextChanged(object sender, TextChangedEventArgs e)
        {

            List<Tables> tables = _dbServ.GetDataTables(_connstr, TableLike.Text.Trim());

            dlcbTables.ItemsSource = tables;

            Sql.Text = "";
        }
    }
}
