﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoGenDB.model;

namespace AutoGenDB.serv
{
    public class CSharpModelServ
    {
        /// <summary>
        /// 產出 .CS Model 內容
        /// </summary>
        /// <param name="schema"></param>
        /// <param name="tableName"></param>
        /// <param name="dataTypes"></param>
        /// <param name="attrs"></param>
        /// <returns></returns>
        public string GetModelCode(string schema, string tableName, List<DataType> dataTypes, List<string> attrs) 
        {
            string rval = "";


            string tbname = tableName;

            string className = "";
            string nameSpace = "";

            nameSpace += "using System;"        + Environment.NewLine;
            nameSpace += "namespace Model {"    + Environment.NewLine + Environment.NewLine;

            className += $"public class {tbname}" + " {" + Environment.NewLine+Environment.NewLine;

            foreach (DataType data in dataTypes) 
            {
                className += "/// <summary>" + data.COMMENT + "</summary>" + Environment.NewLine;
                className += GetPropertyType(data) + Environment.NewLine;
            }

            className += "}" + Environment.NewLine + Environment.NewLine;
            className += "}";

            rval = nameSpace + className;

            return rval;
        }

        /// <summary>
        /// 產出JS column內容
        /// </summary>
        /// <param name="schema"></param>
        /// <param name="tableName"></param>
        /// <param name="dataTypes"></param>
        /// <returns></returns>
        public string GetJSColumnCode(string schema, string tableName, List<DataType> dataTypes)
        {

            string rval = "";

            string column_format = " <Column title='{0}' width={{1}} field='{2}' /> ";

            foreach (DataType dataType in dataTypes)
            {

                string titleattr = "";

                if (string.IsNullOrEmpty(dataType.COMMENT))
                {
                    titleattr = $"title='{dataType.COLUMN_NAME}'";
                }
                else 
                {
                    titleattr = $"title='{dataType.COMMENT}'";
                }

                rval += $"{{/* {dataType.COMMENT} */}} " + Environment.NewLine;
                rval += $"<Column {titleattr} width={{{100}}} field='{dataType.COLUMN_NAME}' /> " + Environment.NewLine;
            }


            return rval;
        }


        private string GetPropertyType(DataType paramDataType)
        {

            string dataType = paramDataType.DATA_TYPE;
            string columnName = paramDataType.COLUMN_NAME;
            string primaryKey = paramDataType.PrimaryKey == "" ? "" : ", PrimaryKey = true";
            string dbType = "";
            string propertyType = "";

            switch (dataType)
            {

                case "bigint"        : dbType = "BigInt";         propertyType = "Int64?"; break;
                case "binary"        : dbType = "Binary";         propertyType = "Byte[]"; break;
                case "bit"           : dbType = "Bit";            propertyType = "Boolean?"; break;
                case "char"          : dbType = "Char";           propertyType = "String"; break;
                case "datetime"      : dbType = "DateTime";       propertyType = "DateTime?"; break;
                case "decimal"       : dbType = "Decimal";        propertyType = "Decimal?"; break;
                case "float"         : dbType = "Float";          propertyType = "Double?"; break;
                case "image"         : dbType = "Image";          propertyType = "Byte[]"; break;
                case "int"           : dbType = "Int";            propertyType = "Int32?"; break;
                case "money"         : dbType = "Money";          propertyType = "Decimal?"; break;
                case "nchar"         : dbType = "NChar";          propertyType = "String"; break;
                case "ntext"         : dbType = "NText";          propertyType = "String"; break;
                case "nvarchar"      : dbType = "NVarChar";       propertyType = "String"; break;
                case "real"          : dbType = "Real";           propertyType = "Single?"; break;
                case "smalldatetime" : dbType = "SmallDateTime";  propertyType = "DateTime?"; break;
                case "smallint"      : dbType = "SmallInt";       propertyType = "Int16?"; break;
                case "smallmoney"    : dbType = "SmallMoney";     propertyType = "Decimal?"; break;
                case "text"          : dbType = "Text";           propertyType = "String"; break;
                case "timestamp"     : dbType = "Timestamp";      propertyType = "Byte[]"; break;
                case "tinyint"       : dbType = "TinyInt";        propertyType = "Byte?"; break;
                case "varbinary"     : dbType = "VarBinary";      propertyType = "Byte[]"; break;
                case "varchar"       : dbType = "VarChar";        propertyType = "String"; break;
                case "variant"       : dbType = "Variant";        propertyType = "Object"; break;
                case "date"          : dbType = "Date";           propertyType = "DateTime?"; break;
                case "datetime2"     : dbType = "DateTime2";      propertyType = "DateTime?"; break;
                case "datetimeoffset": dbType = "DateTimeOffset"; propertyType = "DateTime?"; break;
                case "numeric"       : dbType = "Decimal";        propertyType = "Decimal?"; break;

                default:
                    throw new Exception("Not this DataType：" + dataType);
            }

            string daoFormat = "[DAO(ColumnName = \"{0}\", DBType = SqlDbType.{1} {2})]";

            //string.Format(daoFormat, columnName, dbType, primaryKey) + Environment.NewLine 

            return $"public {propertyType} {columnName}" + " { get; set; }" + Environment.NewLine;

        }
    }
}
