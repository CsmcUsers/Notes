﻿using AutoGenDB.model;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoGenDB.serv
{
    public class dbServ
    {
        public List<DB> GetDataBase(string constr) 
        {
            using (SqlConnection con = new SqlConnection(constr) )
            {

                string sql = " SELECT name DBName FROM master.dbo.sysdatabases ";

                return con.Query<DB>(sql).ToList();
            }
        }

		public List<Tables> GetDataTables(string constr, string tableLike)
		{ 
			List<Tables> tables = new List<Tables>();

			string sql = @"	SELECT TABLE_SCHEMA + '.' + TABLE_NAME TABLE_NAME 
							FROM INFORMATION_SCHEMA.TABLES 
							WHERE 1=1 ";

			if (tableLike != "") 
			{ 
				sql += " AND TABLE_NAME LIKE '" + tableLike + "%'"; 
			}

			sql += " ORDER BY TABLE_NAME";

			using (SqlConnection con = new SqlConnection(constr))
			{
				return con.Query<Tables>(sql).ToList();
			}

		}

		public List<DataType> GetDataTypes(string constr, string tableSche, string tableName) 
        {
			string sql = @"
            SELECT
	            A1.TABLE_SCHEMA,
	            A1.TABLE_NAME,
	            A1.COLUMN_NAME,
	            A3.COMMENT,
	            LOWER(A1.DATA_TYPE) DATA_TYPE,
	            SUBSTRING(ISNULL(A2.CONSTRAINT_NAME, ''), 1, 2) PrimaryKey
            FROM INFORMATION_SCHEMA.COLUMNS A1
	            LEFT JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE A2 ON A1.TABLE_SCHEMA = A2.TABLE_SCHEMA
		            AND A1.TABLE_NAME = A2.TABLE_NAME
		            AND A1.COLUMN_NAME = A2.COLUMN_NAME
	            LEFT JOIN
	            (
		            SELECT
			            ST.name TABLE_NAME,
			            SC.name COLUMN_NAME,
			            SEP.value COMMENT
		            FROM SYS.TABLES ST
			            INNER JOIN SYS.COLUMNS SC ON ST.object_id = SC.object_id
			            LEFT JOIN SYS.EXTENDED_PROPERTIES SEP ON ST.object_id = SEP.major_id
				        AND SC.column_id = SEP.minor_id
				        AND SEP.name = 'MS_Description') A3 ON A1.TABLE_NAME = A3.TABLE_NAME
		                AND A1.COLUMN_NAME = A3.COLUMN_NAME
                WHERE 
                A1.TABLE_NAME = @TABLE_NAME
	            AND A1.TABLE_SCHEMA = @TABLE_SCHEMA ";

			using (SqlConnection con = new SqlConnection(constr))
			{
				return con.Query<DataType>(sql, new { TABLE_NAME = tableName, TABLE_SCHEMA = tableSche }).ToList();
			}
		}
    }
}
