﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoGenDB.model
{
    public class DataType
    {
        public String DATA_TYPE { get; set; }

        public String COLUMN_NAME { get; set; }

        public String COMMENT { get; set; }

        public String PrimaryKey { get; set; }

    }
}
