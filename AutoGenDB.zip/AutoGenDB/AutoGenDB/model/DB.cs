﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoGenDB.model
{
    public class DB
    {
        public string DBName { get; set; }
    }
}
